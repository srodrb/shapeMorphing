simpleFoam > log
